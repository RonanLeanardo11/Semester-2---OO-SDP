# Lab 1 Ronan Breen X00152190

# Modify the program given in the lecture notes (Stock with a menu program)
# 1) Add validation for when you are adding stock:
# i. If the stock ID already exists, just add to its quantity.
# ii. Else create new stock item
 # The rationale for this is to stop duplicate entries.

# 2) Add a sale menu. This menu allows you to enter the stock ID, and then the quantity
# for sale. The quantity of the stock item sold, must then be removed from the quantity
# of the stock item
 # The rationale for this is to stop duplicate entries.

# 3) Add validation to the sale menu, this should not allow a sale to proceed if either of
# the two following criteria are not met:
# i. The sale amount is a negative number
# ii. There is not enough stock for the sale.


# initialise the variable
menuOption = 0

# list
stock = [["Null", "Null", 0, 0],["Null2", "Null2", 1, 1]] ## make list 2d by putting in dummy values. loop/print output will only print from row 2.
                                                            # This is so we don't have to code for both a 1d and 2d loop which is very tricky.
# control the loop while exit option not chosen
while menuOption != 4: # while not = Exit
    print("\t***********************")
    print("\t* Menu *")
    print("\t***********************")
    print("\t* 1) Add Stock *")
    print("\t* 2) Add Sales *")
    print("\t* 3) Stock List *")
    print("\t***********************")
    print("\t* 4) Exit *")
    print("\t***********************")

    menuOption = int(input("\tPlease enter menu option:"))
    Flag = bool(False) # use a bool flag to control if the last if statements in Menus 2/3 should be performed. Below if the script goes into the for loop and finds stock ID matches one of
                        # cols then we reset the flag to "True" so it skips the if statement to enter desc, sale price and append to the list etc...

    # Add Stock Menu
    if menuOption == 1:
        print("\t***********************")
        print("\t* Add Stock *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")

        for i, row in enumerate(stock[2:]): ## [2:] mean to run from row 2 onwards (as first two rows are null to make list 2d)
            for col in row:
                if col == stockID:
                    qty = int(input("\tPlease enter quantity:"))
                    stock[i+2][3] += qty # as running from row 2 need add 2 to i so that it will add to correct row.
                    Flag = bool(True) # reset flag to true so if statement below not executed
                    break # break as only need to add to stock quantity once

        # if statement outside the loop as only needed once - bool flags determine if executed or not.
        if Flag == bool(False): # flag set to false above, but if above if is true it gets reset and this if statement is ignored
            description = input("\tPlease enter stock description:")
            salePrice = float(input("\tPlease enter sale price:"))
            qty = int(input("\tPlease enter quantity:"))
            newStockItem = [stockID, description, salePrice, qty]
            stock.append(newStockItem) # add above to list


    # Add Sales Menu - This menu allows you to enter the stock ID, and then the quantity for sale
    elif menuOption == 2:
        # Flag = bool(False) - don't need as covered in line 39
        print("\t***********************")
        print("\t* Add Sales *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")
        salesQty = int(input("\tPlease enter Sales quantity:")) # has to be outside the for loop so not repeated during validation.
        for i, row in enumerate(stock[2:]): ## [2:] means to run from row 2 onwards (as first two rows are null to make list 2d)
            for col in row:
                if col == stockID: # check if any columns have the stock ID value.
                    # Lab 1.3 - below advises customer to re-enter sales quantity while less than 0 or > stock qty.
                    while salesQty < 0 or stock[i+2][3] < salesQty:
                        print("Sales Quantity cannot be less than or greater than available stock") # warning message that input incorrect
                        salesQty = int(input("\tPlease enter Sales quantity:"))
                        Flag = bool(True) # reset flag to true so if statement for where stock ID not exist below not executed

        # if above if statement line 76 true then boolean flag will be true and this ignored. Otherwise will check if sales equal/above o and less than stock qty.
        if salesQty >= 0 or stock[i+2][3] >= salesQty:
            stock[i+2][3] -= salesQty # Take Sales qty away from stock qty at position where stock ID Exists. As running from row 2 need add 2 to i.
            Flag = bool(True) # reset flag to true so if statement below not executed


        if Flag == bool(False):
            print("Stock ID does not exist")

    # Stock List Menu
    elif menuOption == 3:
        print("\t***********************")
        print("\t* Stock List *")
        print("\t***********************")
        print("\t--------------------------------------------")
        print("\t{0:<10}".format("ID") + "{0:<10}".format("Des") + "{0:<10}".format("RRP") + "{0:<10}".format("QTY"))
        print("\t--------------------------------------------")

        for stockItem in (stock[2:]): # print from row 2 onwards
            print("\t", end="")
            for detail in stockItem:
                print("{0:<10}".format(detail), end="")
            print()

    # Exit Menu/Loop
    elif menuOption == 4:
        pass
    else:
        print("Error - Please enter number between 1 and 3.")