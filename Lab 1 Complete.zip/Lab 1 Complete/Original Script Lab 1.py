menuOption = 0
stock = []
while menuOption != 3:
    print("\t***********************")
    print("\t* Menu *")
    print("\t***********************")
    print("\t* 1) Add Stock *")
    print("\t* 2) Stock List *")
    print("\t***********************")
    print("\t* 3) Exit *")
    print("\t***********************")

    menuOption = int(input("\tPlease enter menu option:"))

    if menuOption == 1:
        print("\t***********************")
        print("\t* Add Stock *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")
        description = input("\tPlease enter stock description:")
        salePrice = float(input("\tPlease enter sale price:"))
        qty = int(input("\tPlease enter quantity:"))
        newStockItem = [stockID, description, salePrice, qty]
        stock.append(newStockItem)

    elif menuOption == 2:
        print("\t***********************")
        print("\t* Stock List *")
        print("\t***********************")
        print("\t--------------------------------------------")
        print("\t{0:<10}".format("ID") + "{0:<10}".format("Des") + "{0:<10}".format("RRP") + "{0:<10}".format("QTY"))
        print("\t--------------------------------------------")

        for stockItem in stock:
            print("\t", end="")
            for detail in stockItem:
                print("{0:<10}".format(detail), end="")
            print()

    elif menuOption == 3:
        pass
    else:
        print("Error - Please enter number between 1 and 3.")