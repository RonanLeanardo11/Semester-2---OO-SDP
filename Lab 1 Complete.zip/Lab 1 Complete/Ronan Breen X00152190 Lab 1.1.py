# Lab 1.1 Ronan Breen X00152190

# Modify the program given in the lecture notes (Stock with a menu program)
# 1) Add validation for when you are adding stock:
# i. If the stock ID already exists, just add to its quantity.
# ii. Else create new stock item
 # The rationale for this is to stop duplicate entries.


# initialise the variable
menuOption = 0
stock = [["Null", "Null", 0, 0],["Null2", "Null2", 1, 1]] ## make list 2d by putting in dummy values. loop/print output will only print from row 2.
                                                            # This is so we don't have to code for both a 1d and 2d loop which is very tricky.

# 
while menuOption != 3: # amended to 3 from 5 so loop can be exited. 5 not an option.
    print("\t***********************")
    print("\t* Menu *")
    print("\t***********************")
    print("\t* 1) Add Stock *")
    print("\t* 2) Stock List *")
    print("\t***********************")
    print("\t* 3) Exit *")
    print("\t***********************")

    menuOption = int(input("\tPlease enter menu option:"))
    Flag = bool(False) # use a bool flag to control if the if statement (to add to list i.e. lines 45 - 50) should be performed. Below if the script goes into the for loop and finds stock ID matches one of
                        # cols then we reset the flag to "True" so it skips the if statement to enter desc, sale price and append to the list etc...

    if menuOption == 1:
        print("\t***********************")
        print("\t* Add Stock *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")

        for i, row in enumerate(stock[2:]): ## [2:] means to run from row 2 onwards (as first two rows are null to make list 2d)
            for col in row:
                if col == stockID:
                    qty = int(input("\tPlease enter quantity:"))
                    stock[i+2][3] += qty # as running from row 2 need to add 2 to i to make sure row is correct.
                    Flag = bool(True) # reset flag to true so if statement below not executed i.e. line 45.
                    break # only want to get qty once so we break from loop if entered

        # if statement outside the loop.
        if Flag == bool(False): # flag set to false above, but if above (line 38) is true it gets reset  to true and this if statement is ignored
            description = input("\tPlease enter stock description:")
            salePrice = float(input("\tPlease enter sale price:"))
            qty = int(input("\tPlease enter quantity:"))
            newStockItem = [stockID, description, salePrice, qty]
            stock.append(newStockItem)


    elif menuOption == 2:
        print("\t***********************")
        print("\t* Stock List *")
        print("\t***********************")
        print("\t--------------------------------------------")
        print("\t{0:<10}".format("ID") + "{0:<10}".format("Des") + "{0:<10}".format("RRP") + "{0:<10}".format("QTY"))
        print("\t--------------------------------------------")

        for stockItem in (stock[2:]): # print from row 2 onwards
            print("\t", end="")
            for detail in stockItem:
                print("{0:<10}".format(detail), end="")
            print()

    elif menuOption == 3:
        pass
    else:
        print("Error - Please enter number between 1 and 3.")