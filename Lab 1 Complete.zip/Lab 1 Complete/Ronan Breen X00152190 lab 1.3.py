# Lab 1.3 Ronan Breen X00152190

# 3) Add validation to the sale menu, this should not allow a sale to proceed if either of
# the two following criteria are not met:
# i. The sale amount is a negative number
# ii. There is not enough stock for the sale.

# initialise the variable
menuOption = 0

# List
stock = [["Null", "Null", 0, 0],["Null2", "Null2", 1, 1]]

# while menu option not exit option
while menuOption != 4:
    print("\t***********************")
    print("\t* Menu *")
    print("\t***********************")
    print("\t* 1) Add Stock *")
    print("\t* 2) Add Sales *")
    print("\t* 3) Stock List *")
    print("\t***********************")
    print("\t* 4) Exit *")
    print("\t***********************")

    menuOption = int(input("\tPlease enter menu option:"))
    Flag = bool(False)

    # Add Stock Menu
    if menuOption == 1:
        print("\t***********************")
        print("\t* Add Stock *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")

        for i, row in enumerate(stock[2:]):
            for col in row:
                if col == stockID:
                    qty = int(input("\tPlease enter quantity:"))
                    stock[i+2][3] += qty
                    Flag = bool(True)
                    break

        # if statement outside the loop.
        if Flag == bool(False):
            description = input("\tPlease enter stock description:")
            salePrice = float(input("\tPlease enter sale price:"))
            qty = int(input("\tPlease enter quantity:"))
            newStockItem = [stockID, description, salePrice, qty]
            stock.append(newStockItem)

    # Add Sales Menu
    elif menuOption == 2:
        Flag = bool(False)
        print("\t***********************")
        print("\t* Add Sales *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")
        salesQty = int(input("\tPlease enter Sales quantity:")) ## put outside loop so question not repeeated for validation
        for i, row in enumerate(stock[2:]):
            for col in row:
                if col == stockID:
                    # Validation where sale amount less than zero or There is not enough stock for the sale.
                    while salesQty < 0 or stock[i+2][3] < salesQty:
                        print("Sales Quantity cannot be less than or greater than available stock")
                        salesQty = int(input("\tPlease enter Sales quantity:"))
                        Flag = bool(True) # reset flag to true so if statement below not executed

        # opposite to validation above i.e. anything greater than zero or above stock qty
        if salesQty >= 0 or stock[i+2][3] >= salesQty:
            stock[i+2][3] -= salesQty # Take Sales qty away from stock row at position quantity where stock ID Exists. As running from row 2 need to add 2 to i as that will run from row 0
            Flag = bool(True) # reset flag to true so if statement below not executed


        elif Flag == bool(False):
            print("Stock ID does not exist")

    # Stock List Menu
    elif menuOption == 3:
        print("\t***********************")
        print("\t* Stock List *")
        print("\t***********************")
        print("\t--------------------------------------------")
        print("\t{0:<10}".format("ID") + "{0:<10}".format("Des") + "{0:<10}".format("RRP") + "{0:<10}".format("QTY"))
        print("\t--------------------------------------------")

        for stockItem in (stock[2:]): # print from row 2 onwards
            print("\t", end="")
            for detail in stockItem:
                print("{0:<10}".format(detail), end="")
            print()

    # Exit Menu/Loop
    elif menuOption == 4:
        pass
    else:
        print("Error - Please enter number between 1 and 3.")