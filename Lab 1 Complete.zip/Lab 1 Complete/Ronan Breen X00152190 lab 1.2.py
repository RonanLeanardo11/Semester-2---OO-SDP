# Lab 1.2 Ronan Breen X00152190

# 2) Add a sale menu. This menu allows you to enter the stock ID, and then the quantity
# for sale. The quantity of the stock item sold, must then be removed from the quantity
# of the stock item
 # The rationale for this is to stop duplicate entries.


# initialise the variable
menuOption = 0

# list
stock = [["Null", "Null", 0, 0],["Null2", "Null2", 1, 1]]

#
while menuOption != 4: #amended to 3 from 4 so loop can be exited. 3 no longer the Exit menu option as we have added menu 2 for Sales..
    print("\t***********************")
    print("\t* Menu *")
    print("\t***********************")
    print("\t* 1) Add Stock *")
    print("\t* 2) Add Sales *") # Added Sales Menu
    print("\t* 3) Stock List *") # Amended to option 3
    print("\t***********************")
    print("\t* 4) Exit *")# Amended to option 3
    print("\t***********************")

    menuOption = int(input("\tPlease enter menu option:"))
    Flag = bool(False)


    # Add Stock Menu
    if menuOption == 1:
        print("\t***********************")
        print("\t* Add Stock *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")

        for i, row in enumerate(stock[2:]):
            for col in row:
                if col == stockID:
                    qty = int(input("\tPlease enter quantity:"))
                    stock[i+2][3] += qty
                    Flag = bool(True)
                    break

        # if statement outside the loop.
        if Flag == bool(False):
            description = input("\tPlease enter stock description:")
            salePrice = float(input("\tPlease enter sale price:"))
            qty = int(input("\tPlease enter quantity:"))
            newStockItem = [stockID, description, salePrice, qty]
            stock.append(newStockItem)


    # Add Sales Menu
    elif menuOption == 2:
        print("\t***********************")
        print("\t* Add Sales *")
        print("\t***********************")
        stockID = input("\tPlease enter stock ID:")
        for i, row in enumerate(stock[2:]): ## [2:] mean to run from row 2 onwards (as first two rows are null to make list 2d)
            for col in row:
                if col == stockID:
                    salesQty = int(input("\tPlease enter Sales quantity:"))
                    stock[i+2][3] -= salesQty # Take Sales qty away from stock qty row. As running from row 2 need add 2 to i as that will take away from row 0 otherwise.
                    Flag = bool(True) # reset flag to true so if statement below not executed
                    break # exit loop as only need to do once

        if Flag == bool(False):
            print("Stock ID does not exist")

    # Stock List Menu
    elif menuOption == 3: # amended to option 3
        print("\t***********************")
        print("\t* Stock List *")
        print("\t***********************")
        print("\t--------------------------------------------")
        print("\t{0:<10}".format("ID") + "{0:<10}".format("Des") + "{0:<10}".format("RRP") + "{0:<10}".format("QTY"))
        print("\t--------------------------------------------")

        for stockItem in (stock[2:]): # print from row 2 onwards
            print("\t", end="")
            for detail in stockItem:
                print("{0:<10}".format(detail), end="")
            print()

    # Exit Menu/Loop
    elif menuOption == 4:
        pass
    else:
        print("Error - Please enter number between 1 and 3.")