# Lab 2.1 Files Ronan Breen X00152190

# Q1)
# Write a Python program that askes the user for a person’s name. Once entered this name is
# then added to a .txt file.
# This is looped 5 times, and each time the information is appended to the .txt file.

# Open File, in append mode
logfile = open("Lab2.1Names.txt", "a")

# Can have a heading but will print each time names are added
# logfile.write("\n *********** Logfile Names *********** \n")

# Iterate loop 5 times
for i in range(5):
    UserInput = input("Please enter your name: ") # Get user input
    UserInput = UserInput.capitalize() # Capitalize first letter
    logfile.write("\n" + str(UserInput)) # write user input to file with new line each time

logfile.close() # close file