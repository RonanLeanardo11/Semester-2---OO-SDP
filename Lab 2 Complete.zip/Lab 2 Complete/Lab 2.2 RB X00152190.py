# Lab 2.2 Files Ronan Breen X00152190

# Q2)
# Allow the user to enter a name to be searched (you must assume it is case sensitive). The
# program should then open the .txt file from Q1, and return a prompt if the name was in the file.
# (Hint: use split to split the data into a 1D list, using new line. Then search the list)

# Open File, in read mode
logfile = open("Lab2.2Names.txt", "r")
text = logfile.read()

# Split all words into a 1D list
allWords = text.split("\n") # Split be new line
# print(allWords) just checking list printing correctly

UserInput = input("Please enter your name: ") # Get user input

# iterate through all the values in our list
for word in allWords:
    if UserInput.capitalize() == word or UserInput == word: # Capitalize first letter to match our list, or allow lower case.
        print("Name already exists in the file")
        break # only need error message to show once so use a break to exit loop

logfile.close() #close file